#pragma once

class Dirent
{
};

