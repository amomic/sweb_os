#pragma once

#include "Thread.h"

class IdleThread : public Thread
{
  public:
    IdleThread();

    virtual void Run();
};

